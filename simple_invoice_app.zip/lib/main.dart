
import 'package:flutter/material.dart';

void main() {
  runApp(SimpleInvoiceApp());
}

class SimpleInvoiceApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'اپلیکیشن فاکتور ساده',
      theme: ThemeData(
        fontFamily: 'Vazir',
        primarySwatch: Colors.blue,
      ),
      home: CustomerListPage(),
    );
  }
}

class Customer {
  String name;
  String phone;
  String address;

  Customer(this.name, this.phone, this.address);
}

class Invoice {
  Customer customer;
  int quantity;
  double unitPrice;

  Invoice(this.customer, this.quantity, this.unitPrice);

  double get total => quantity * unitPrice;
}

class CustomerListPage extends StatefulWidget {
  @override
  _CustomerListPageState createState() => _CustomerListPageState();
}

class _CustomerListPageState extends State<CustomerListPage> {
  List<Customer> customers = [];
  List<Invoice> invoices = [];

  final nameController = TextEditingController();
  final phoneController = TextEditingController();
  final addressController = TextEditingController();

  final quantityController = TextEditingController();
  final priceController = TextEditingController();

  Customer? selectedCustomer;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('مدیریت مشتریان و فاکتور'),
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: ListView(
          children: [
            Text('افزودن مشتری', style: TextStyle(fontWeight: FontWeight.bold)),
            TextField(
              controller: nameController,
              decoration: InputDecoration(labelText: 'نام مشتری'),
            ),
            TextField(
              controller: phoneController,
              decoration: InputDecoration(labelText: 'شماره تلفن'),
            ),
            TextField(
              controller: addressController,
              decoration: InputDecoration(labelText: 'آدرس'),
            ),
            ElevatedButton(
              onPressed: () {
                setState(() {
                  customers.add(Customer(
                    nameController.text,
                    phoneController.text,
                    addressController.text,
                  ));
                  nameController.clear();
                  phoneController.clear();
                  addressController.clear();
                });
              },
              child: Text('ثبت مشتری'),
            ),
            Divider(),
            Text('ثبت فاکتور فروش', style: TextStyle(fontWeight: FontWeight.bold)),
            DropdownButton<Customer>(
              hint: Text('انتخاب مشتری'),
              value: selectedCustomer,
              items: customers.map((customer) {
                return DropdownMenuItem<Customer>(
                  value: customer,
                  child: Text(customer.name),
                );
              }).toList(),
              onChanged: (Customer? newCustomer) {
                setState(() {
                  selectedCustomer = newCustomer;
                });
              },
            ),
            TextField(
              controller: quantityController,
              keyboardType: TextInputType.number,
              decoration: InputDecoration(labelText: 'تعداد کالا'),
            ),
            TextField(
              controller: priceController,
              keyboardType: TextInputType.number,
              decoration: InputDecoration(labelText: 'قیمت واحد (ریال)'),
            ),
            ElevatedButton(
              onPressed: () {
                if (selectedCustomer != null &&
                    quantityController.text.isNotEmpty &&
                    priceController.text.isNotEmpty) {
                  setState(() {
                    invoices.add(Invoice(
                      selectedCustomer!,
                      int.tryParse(quantityController.text) ?? 0,
                      double.tryParse(priceController.text) ?? 0,
                    ));
                    quantityController.clear();
                    priceController.clear();
                  });
                }
              },
              child: Text('ثبت فاکتور'),
            ),
            Divider(),
            Text('لیست مشتریان', style: TextStyle(fontWeight: FontWeight.bold)),
            ...customers.map((c) => ListTile(
              title: Text(c.name),
              subtitle: Text('تلفن: ' + c.phone + ' - آدرس: ' + c.address),
            )),
            Divider(),
            Text('لیست فاکتورها', style: TextStyle(fontWeight: FontWeight.bold)),
            ...invoices.map((inv) => ListTile(
              title: Text(inv.customer.name + ' - تعداد: ' + inv.quantity.toString()),
              subtitle: Text('جمع کل: ' + inv.total.toStringAsFixed(0) + ' ریال'),
            )),
          ],
        ),
      ),
    );
  }
}
